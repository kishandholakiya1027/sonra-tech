import axios from 'axios';
import api from './api';

const getBookData = (query: string, num: number) => {
    return api(`https://www.googleapis.com/books/v1/volumes?q=${query}&startIndex=${num}&maxResults=10&key=${process.env.REACT_APP_GOOGLE_API_KEY}`, "get", null)
}

export {
    getBookData
}